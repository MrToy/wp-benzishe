<?php

add_theme_support('post-thumbnails');
register_nav_menus(array('top'=>'页面菜单','middle'=>'分类菜单'));

?>